/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crawlertest;

import java.io.IOException;

/**
 *
 * @author christones
 */
public class SampleSynonyms implements SynonymEngine{
private String[] sample ;
    @Override
    public String[] getSynonyms(String s) throws IOException {
      sample = new String[] {s} ;  
    return sample ;
    } 
}
